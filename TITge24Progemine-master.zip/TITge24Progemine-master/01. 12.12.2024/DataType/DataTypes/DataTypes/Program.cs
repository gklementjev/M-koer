﻿namespace DataTypes
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Data types!");

            //täisnumber
            int bigNumber = 124444445;
            Console.WriteLine(bigNumber);

            //komaga number
            double comaNumber = 12.5;
            Console.WriteLine(comaNumber);

            //tähemärk
            string stringVar = "asdasd12354@#   $%&*()-+";
            Console.WriteLine(stringVar);

            float floatVarible = 123.123F;
            Console.WriteLine(floatVarible);

            char charVarible = '2';
            Console.WriteLine(charVarible);

            bool boolVarible = false;
            Console.WriteLine(boolVarible);
        }
    }
}
