﻿namespace IfAndElse
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, Dogs!");

            string dog = Console.ReadLine();

            if (dog == "hunt")
            {
                Console.WriteLine("Sul on hundikoer");
            }
            else if (dog == "taksi")
            {
                Console.WriteLine("Sul on taksikoer");
            }
            else
            {
                Console.WriteLine("Sul on krants");
            }
            //kood tuleb githubi panna ja kasutada git programmi
            //õpetused asuvad Tahvlis
            //ise valid ühe git programmi välja
        }
    }
}
