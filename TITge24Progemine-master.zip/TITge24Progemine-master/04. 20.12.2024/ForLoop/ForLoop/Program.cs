﻿namespace ForLoop
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            int uhuu = 3;

            for (int i = 0; i < uhuu; i++)
            {
                Console.WriteLine("Tere uhuu");
            }
        }
    }
}
